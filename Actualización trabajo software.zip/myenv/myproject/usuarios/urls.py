from django.urls import path
from django.views.generic import RedirectView
from .views import registrarse, iniciar_sesion, crearperfil, ver_perfil, cerrar_sesion

urlpatterns = [
    path('', RedirectView.as_view(url='registrarse/', permanent=True)),
    path('registrarse/', registrarse, name='registrarse'),
    path('iniciarSesion/', iniciar_sesion, name='iniciar_sesion'),
    path('crear_perfil/', crearperfil, name='crear_perfil'),
    path('ver_perfil/', ver_perfil, name='ver_perfil'),
    path('cerrar_sesion/', cerrar_sesion, name='cerrar_sesion'),
]

