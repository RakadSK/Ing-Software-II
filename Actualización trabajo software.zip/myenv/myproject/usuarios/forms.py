from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Usuario

# Formulario de Registro
class RegistroForm(UserCreationForm):
    correo = forms.EmailField(required=True, help_text='Requerido. Introduce una dirección de correo válida.')

    class Meta:
        model = Usuario  # Aquí utilizamos tu modelo personalizado 'Usuario'
        fields = ['correo', 'nombre', 'apellido', 'password1', 'password2']  # Asegúrate de que estos campos existen en tu modelo 'Usuario'

    def save(self, commit=True):
        user = super().save(commit=False)
        user.correo = self.cleaned_data['correo']
        if commit:
            user.save()
        return user

# Formulario de Inicio de Sesión
class IniciarSesionForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'autofocus': True}))
    password = forms.CharField(
        label="Contraseña",
        strip=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'current-password'}),
    )

# Formulario de Crear Perfil
class PerfilForm(forms.ModelForm):
    class Meta:
        model = Usuario  # Usamos el modelo Usuario que contiene los datos del perfil
        fields = ['nombre', 'apellido', 'correo']  # Asegúrate de que estos campos estén en tu modelo 'Usuario'
