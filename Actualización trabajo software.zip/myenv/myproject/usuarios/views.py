from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.generic import RedirectView  # Importa RedirectView
from .forms import PerfilForm, RegistroForm, IniciarSesionForm  # Usamos los formularios personalizados
from .models import Usuario

# Vista para registrarse
def registrarse(request):
    if request.method == 'POST':
        form = RegistroForm(request.POST)  # Usamos RegistroForm en lugar de UserCreationForm
        if form.is_valid():
            user = form.save()
            login(request, user)  # Iniciar sesión automáticamente después de registrarse
            return redirect('crearPerfil')  # Redirigir a la vista de creación de perfil
    else:
        form = RegistroForm()  # Usamos el formulario de registro personalizado

    return render(request, 'usuarios/registrarse.html', {'form': form})

# Vista para iniciar sesión
def iniciar_sesion(request):
    if request.method == 'POST':
        form = IniciarSesionForm(request, data=request.POST)  # Usamos IniciarSesionForm personalizado
        if form.is_valid():
            correo = form.cleaned_data.get('username')  # Usamos correo para autenticación
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=correo, password=password)  # Autenticación basada en correo
            if user is not None:
                login(request, user)
                return redirect('perfil')  # Redirigir al perfil del usuario
            else:
                form.add_error(None, "Credenciales inválidas")  # Mensaje de error si la autenticación falla
    else:
        form = IniciarSesionForm()  # Formulario para iniciar sesión

    return render(request, 'usuarios/iniciarSesion.html', {'form': form})

# Vista para crear el perfil de usuario
@login_required
def crearperfil(request):
    if request.method == 'POST':
        form = PerfilForm(request.POST)
        if form.is_valid():
            perfil = form.save(commit=False)
            perfil.user = request.user  # Asignamos el usuario al perfil
            perfil.save()
            return redirect('perfil')  # Redirigir a la vista de perfil
    else:
        form = PerfilForm()  # Si no es POST, mostramos el formulario vacío

    return render(request, 'usuarios/crearPerfil.html', {'form': form})

# Vista para ver el perfil del usuario actual
@login_required
def ver_perfil(request):
    try:
        perfil = Usuario.objects.get(correo=request.user.email)  # Buscamos el perfil por correo
    except Usuario.DoesNotExist:
        return redirect('crearPerfil')  # Si el perfil no existe, redirigimos a crear perfil

    context = {
        'perfil': perfil,
    }
    return render(request, 'usuarios/ver_perfil.html', context)

# Vista para cerrar sesión
@login_required
def cerrar_sesion(request):
    logout(request)
    return redirect('iniciarSesion')  # Redirigir a la página de inicio de sesión


