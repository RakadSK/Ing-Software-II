from django.test import TestCase, Client
from django.urls import reverse
from .views import registrarse, iniciar_sesion, crearperfil, ver_perfil, cerrar_sesion
from .models import Usuario  # Import the Usuario model
from .forms import RegistroForm, IniciarSesionForm, PerfilForm  # Import the 

class IniciarSesionViewTest(TestCase):
    def test_get_request_renders_form(self):
        response = self.client.get(reverse('iniciar_sesion'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'usuarios/iniciarSesion.html')
        self.assertIsInstance(response.context['form'], IniciarSesionForm)

    def test_post_request_logs_in_user(self):
        user = Usuario.objects.create_user('test@example.com', 'test@example.com', 'password123')
        data = {'username': 'test@example.com', 'password': 'password123'}
        response = self.client.post(reverse('iniciar_sesion'), data)
        self.assertEqual(response.status_code, 302)  # Redirect to perfil
        self.assertTrue(response.wsgi_request.user.is_authenticated)

    def test_post_request_invalid_credentials_returns_error(self):
        data = {'username': 'test@example.com', 'password': 'wrongpassword'}
        response = self.client.post(reverse('iniciar_sesion'), data)
        self.assertEqual(response.status_code, 200)
        self.assertFormError(response, 'form', None, 'Credenciales inválidas')
